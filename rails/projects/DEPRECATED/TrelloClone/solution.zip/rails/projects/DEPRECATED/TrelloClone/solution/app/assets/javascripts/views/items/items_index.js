TrelloClone.Views.ItemsIndex = Backbone.View.extend({
  template: JST['items/index']
});
