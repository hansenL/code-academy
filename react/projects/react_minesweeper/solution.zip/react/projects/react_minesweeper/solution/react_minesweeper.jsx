const Game = require('./components/game');
const React = require('react');
const ReactDOM = require('react-dom');

ReactDOM.render(
  <Game />,
  document.getElementById('main')
);
