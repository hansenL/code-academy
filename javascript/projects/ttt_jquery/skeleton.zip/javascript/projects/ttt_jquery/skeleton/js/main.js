const View = // require appropriate file
const Game = // require appropriate file

$( () => {
  // Your code here
});
