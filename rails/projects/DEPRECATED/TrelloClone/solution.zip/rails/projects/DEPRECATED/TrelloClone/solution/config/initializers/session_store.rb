# Be sure to restart your server when you modify this file.

TrelloClone::Application.config.session_store :cookie_store, key: '_TrelloClone_session'
