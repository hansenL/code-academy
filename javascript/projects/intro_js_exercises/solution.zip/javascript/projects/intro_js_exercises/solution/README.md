 * [Reversi Bonus Solution][reversi-bonus-solution]
 * [:movie_camera: (cc) Make Change (Ruby)][make-change]
 * [:movie_camera: (cc) Subsets (Ruby)][subsets]

[reversi-bonus-solution]: ../projects/js-reversi/solution
[make-change]: https://vimeo.com/groups/appacademy/videos/91207646
[subsets]: https://vimeo.com/groups/appacademy/videos/91207645
