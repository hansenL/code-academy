var SessionConstants = {
	LOGIN: "LOGIN",
	LOGOUT: "LOGOUT"
};

module.exports = SessionConstants;