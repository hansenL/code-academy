const MoveError = function (msg) { this.msg = msg; };

module.exports = MoveError;
