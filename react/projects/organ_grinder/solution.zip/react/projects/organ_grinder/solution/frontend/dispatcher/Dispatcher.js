var Dispatcher = require('flux').Dispatcher;
var AppDispatcher = new Dispatcher();

module.exports = AppDispatcher;
