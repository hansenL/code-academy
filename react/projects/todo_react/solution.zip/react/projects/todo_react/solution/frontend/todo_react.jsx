var React = require('react');
var ReactDOM = require('react-dom');
var root = document.getElementById('root');
var TodoList = require('./components/todo_list');

ReactDOM.render(<TodoList />, root);
