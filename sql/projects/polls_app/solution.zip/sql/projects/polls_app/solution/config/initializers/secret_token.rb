# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
PollsApp::Application.config.secret_token = 'ebf8562c2d37d624e3bbd2f8315d5074ba0848e8c5bad3943ac713608fb1ed8165b8d19990fc429f40c583c048ae13bcfff137911829a93a531b854706c954c9'
